#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Full, local-only VCE profile benchmark for macOS / Apple Silicon.

Runs one quality-oriented baseline, each experimental checkbox independently,
and one all-experiments profile. Reads active VCE settings but never writes them.
Full VCE responses/transcripts and machine telemetry remain on the user's Mac.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import http.client
import json
import os
import platform
import re
import shutil
import socket
import statistics
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any

DEFAULT_VIDEO = Path.home() / "Downloads" / "video.mp4"  # override via --video or VCE_VIDEO_PATH
DEFAULT_PROJECT = Path.home() / "VideoContext-Engine"
DEFAULT_API = "http://127.0.0.1:7555"
DEFAULT_OUTPUT = Path.home() / "Downloads" / "VCE_Full_Profile_Benchmark"
LOG_CANDIDATES = [
    Path.home() / "Library/Logs/VideoContext Engine/server.log",
    Path("/tmp/vce-live-mlx-audio-test.log"),
    Path("/tmp/vce-live-mlx-test.log"),
    Path("/tmp/vce-live-mlx-integration.log"),
]
FORM_EXCLUDE = {"video_file", "local_video_token", "video_url", "job_id"}
PROMPT_FIELDS = {"visual_user_prompt", "summary_user_prompt"}
DYNAMIC_SETTINGS = {"ffmpeg_ocr_available", "ffmpeg_ocr_reason", "qwen35_text_stage_note"}


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def json_write(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def jsonl_append(path: Path, obj: Any) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(obj, ensure_ascii=False, default=str) + "\n")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run_command(args: list[str], timeout: float = 8.0) -> tuple[int | None, str, str]:
    try:
        result = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False)
        return result.returncode, result.stdout or "", result.stderr or ""
    except Exception as exc:
        return None, "", repr(exc)


def http_json(url: str, timeout: float = 10.0) -> tuple[int, Any, str]:
    request = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "VCE-Full-Profile-Benchmark/1.0"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
            status = response.status
    except urllib.error.HTTPError as exc:
        raw, status = exc.read(), exc.code
    decoded = raw.decode("utf-8", "replace")
    try:
        data = json.loads(decoded) if decoded else {}
    except Exception:
        data = {"_raw": decoded[:10000]}
    return status, data, decoded


def api_is_ready(api_url: str) -> bool:
    try:
        status, data, _ = http_json(api_url.rstrip("/") + "/openapi.json", timeout=3.0)
        return status == 200 and isinstance(data, dict) and "paths" in data
    except Exception:
        return False


def maybe_start_app(api_url: str, wait_seconds: int = 120) -> bool:
    if api_is_ready(api_url):
        return True
    print("VCE API не отвечает. Пробую открыть установленное приложение VideoContext Engine.app …", flush=True)
    app_path = Path("/Applications/VideoContext Engine.app")
    if app_path.exists():
        rc, out, err = run_command(["/usr/bin/open", "-a", str(app_path)], timeout=10)
        if rc not in (0, None):
            print(f"Не удалось открыть .app: {err or out}", file=sys.stderr)
    else:
        print(f"Приложение не найдено: {app_path}", file=sys.stderr)
    deadline = time.monotonic() + wait_seconds
    while time.monotonic() < deadline:
        if api_is_ready(api_url):
            return True
        time.sleep(2)
    return api_is_ready(api_url)


def load_api_schema(api_url: str) -> tuple[dict[str, Any], str, dict[str, Any]]:
    status, spec, raw = http_json(api_url.rstrip("/") + "/openapi.json", timeout=10)
    if status != 200 or not isinstance(spec, dict):
        raise RuntimeError(f"OpenAPI недоступен: HTTP {status}; {raw[:1000]}")
    operation = spec.get("paths", {}).get("/api/v1/analyze", {}).get("post")
    if not operation:
        raise RuntimeError("В OpenAPI отсутствует POST /api/v1/analyze.")
    body = operation.get("requestBody", {}).get("content", {})
    schema = body.get("multipart/form-data", {}).get("schema", {})
    ref = schema.get("$ref")
    if ref:
        prefix = "#/components/schemas/"
        if not ref.startswith(prefix):
            raise RuntimeError(f"Неизвестная ссылка схемы OpenAPI: {ref}")
        schema = spec.get("components", {}).get("schemas", {}).get(ref[len(prefix):], {})
    properties = schema.get("properties", {})
    if "video_file" not in properties:
        raise RuntimeError("OpenAPI не объявляет поле video_file; остановка без загрузки видео.")
    progress_path = next((p for p in spec.get("paths", {}) if "/progress/" in p and "{" in p), "")
    return properties, progress_path, spec


def read_local_settings(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError(f"Корень {path} должен быть JSON-объектом.")
    return value


def get_memory_bytes() -> int | None:
    rc, out, _ = run_command(["/usr/sbin/sysctl", "-n", "hw.memsize"], timeout=3)
    if rc == 0:
        try:
            return int(out.strip())
        except ValueError:
            return None
    return None


def pick_log(explicit: str | None) -> Path | None:
    if explicit:
        candidate = Path(explicit).expanduser()
        return candidate if candidate.is_file() else None
    return next((p for p in LOG_CANDIDATES if p.is_file()), None)


def ffprobe_duration(video: Path) -> float | None:
    binary = shutil.which("ffprobe")
    if not binary:
        return None
    rc, out, _ = run_command([binary, "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(video)], timeout=20)
    if rc == 0:
        try:
            return float(out.strip())
        except ValueError:
            pass
    return None


def encode_form(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value)


def build_base_fields(properties: dict[str, Any], active: dict[str, Any], memory_bytes: int | None) -> tuple[dict[str, Any], list[str]]:
    fields: dict[str, Any] = {}
    for name, definition in properties.items():
        if name in FORM_EXCLUDE or name in PROMPT_FIELDS:
            continue
        if name in active:
            fields[name] = active[name]
        elif isinstance(definition, dict) and "default" in definition:
            fields[name] = definition["default"]

    # Hardware-aware visual resolution: 1280 was the best documented quality/speed
    # compromise for text-heavy presentations on 32 GB M1 Max; 768 is the current
    # conservative packaged default on smaller unified-memory systems.
    ram_gib = memory_bytes / (1024 ** 3) if memory_bytes else None
    resolution = 1280 if ram_gib is not None and ram_gib >= 32 else 768
    ffmpeg_available = active.get("ffmpeg_ocr_available") is True
    overrides: dict[str, Any] = {
        "analysis_mode": "full",
        "skip_audio": False,
        "skip_visual": False,
        "vlm_model": "mlx-community/Qwen3-VL-8B-Instruct-4bit",
        "whisper_model": "large",
        "vlm_resolution": resolution,
        "scene_threshold": 0.15,
        "min_scene_duration": 1.5,
        "max_scene_duration": 20,
        "keyframes_per_scene": 1,
        "vlm_max_tokens_scene": 1024,
        "vlm_max_tokens_summary": 2048,
        "enable_apple_ocr": True,
        "enable_ffmpeg_ocr": ffmpeg_available,
        "ffmpeg_ocr_interval": 5,
        "ffmpeg_ocr_workers": 3,
        "whisper_acceleration": True,
        "enable_audio_features": True,
        "generate_summary": True,
        "generate_txt": False,
        "generate_json": False,
        "word_timestamps": True,
        "text_llm_enabled": True,
        "enable_stage_timing": True,
        "enable_adaptive_keyframes": False,
        "enable_ocr_cache": False,
        "enable_mlx_whisper": False,
        "enable_fast_scene_detection": False,
        "response_format": "json",
    }
    for key, value in overrides.items():
        if key in properties:
            fields[key] = value
    missing = [key for key in overrides if key not in properties]
    return fields, missing


def build_plan(base_fields: dict[str, Any], properties: dict[str, Any], include_combined: bool = True) -> list[tuple[str, str, dict[str, Any]]]:
    experiments = [
        ("adaptive_keyframes", "Адаптивные кадры (предел 2 кадра)", {"enable_adaptive_keyframes": True, "keyframes_per_scene": 2}),
        ("ocr_cache", "Кэш Apple Vision OCR", {"enable_ocr_cache": True}),
        ("mlx_whisper_flag", "Флаг MLX Whisper", {"enable_mlx_whisper": True}),
        ("fast_scene_detection", "Быстрая детекция сцен (1 кадр/с)", {"enable_fast_scene_detection": True}),
    ]
    plan: list[tuple[str, str, dict[str, Any]]] = [("baseline", "Оптимальный базовый профиль", {})]
    for key, label, values in experiments:
        absent = [name for name in values if name not in properties]
        if absent:
            raise RuntimeError(f"Локальный API не подтверждает поля {absent}; не буду имитировать эксперимент.")
        plan.append((key, label, values))
    if include_combined:
        combined = {
            "enable_adaptive_keyframes": True,
            "enable_ocr_cache": True,
            "enable_mlx_whisper": True,
            "enable_fast_scene_detection": True,
            "keyframes_per_scene": 2,
        }
        absent = [name for name in combined if name not in properties]
        if absent:
            raise RuntimeError(f"API не подтверждает настройки комбинированного эксперимента: {absent}")
        plan.append(("all_experiments", "Все экспериментальные функции вместе", combined))
    return [(key, label, overrides) for key, label, overrides in plan]


def get_listener_pids(port: int) -> list[int]:
    rc, out, _ = run_command(["/usr/sbin/lsof", "-nP", f"-iTCP:{port}", "-sTCP:LISTEN", "-t"], timeout=4)
    result: list[int] = []
    if rc == 0:
        for token in out.split():
            try:
                result.append(int(token))
            except ValueError:
                pass
    return sorted(set(result))


def process_snapshot(root_pids: set[int]) -> list[dict[str, Any]]:
    rc, out, _ = run_command(["/bin/ps", "-axo", "pid=,ppid=,%cpu=,rss=,etime=,command="], timeout=5)
    if rc != 0:
        return []
    rows: dict[int, dict[str, Any]] = {}
    for line in out.splitlines():
        parts = line.strip().split(None, 5)
        if len(parts) < 6:
            continue
        try:
            pid, ppid = int(parts[0]), int(parts[1])
            cpu, rss = float(parts[2]), int(parts[3])
        except ValueError:
            continue
        rows[pid] = {"pid": pid, "ppid": ppid, "cpu_percent": cpu, "rss_kib": rss, "rss_mib": round(rss / 1024, 2), "elapsed": parts[4], "command": parts[5][:500]}
    selected = set(root_pids)
    changed = True
    while changed:
        changed = False
        for pid, row in rows.items():
            if row["ppid"] in selected and pid not in selected:
                selected.add(pid)
                changed = True
    return [rows[pid] for pid in sorted(selected) if pid in rows]


def memory_snapshot() -> dict[str, Any]:
    data: dict[str, Any] = {}
    for key, cmd in (
        ("memory_pressure", ["/usr/bin/memory_pressure", "-Q"]),
        ("swap", ["/usr/sbin/sysctl", "vm.swapusage"]),
    ):
        rc, out, err = run_command(cmd, timeout=6)
        data[key] = {"returncode": rc, "output": (out or err)[:4000]}
    return data


def powermetrics_command() -> tuple[list[str] | None, str]:
    binary = "/usr/bin/powermetrics"
    if not Path(binary).is_file():
        return None, "not_installed"
    command = [binary, "--samplers", "gpu_power", "-i", "1000", "-n", "1"]
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        return command, "root"
    sudo = shutil.which("sudo")
    if sudo:
        rc, _, _ = run_command([sudo, "-n", "true"], timeout=3)
        if rc == 0:
            return [sudo, "-n", *command], "sudo_noninteractive"
    return None, "permission_required_or_sudo_unavailable"


def parse_gpu_sample(output: str) -> dict[str, float]:
    result: dict[str, float] = {}
    patterns = {
        "gpu_active_residency_percent": r"GPU HW active residency:\s*([0-9.]+)%",
        "gpu_active_frequency_mhz": r"GPU HW active frequency:\s*([0-9.]+)\s*MHz",
        "gpu_power_mw": r"GPU Power:\s*([0-9.]+)\s*mW",
    }
    for key, pattern in patterns.items():
        match = re.search(pattern, output, re.I)
        if match:
            result[key] = float(match.group(1))
    return result


def drain_server_log(path: Path | None, offset: int, target: Path) -> tuple[int, str]:
    if not path or not path.is_file():
        return offset, ""
    try:
        size = path.stat().st_size
        if size < offset:
            offset = 0  # log was rotated/truncated
        with path.open("rb") as handle:
            handle.seek(offset)
            raw = handle.read()
            next_offset = handle.tell()
        text = raw.decode("utf-8", "replace")
        if text:
            with target.open("a", encoding="utf-8") as output:
                output.write(text)
        return next_offset, text
    except Exception as exc:
        return offset, f"[log read error] {exc}\n"


def build_multipart(fields: dict[str, Any], video: Path, boundary: str, job_id: str) -> tuple[bytes, bytes, int]:
    chunks: list[bytes] = []
    clean_fields = dict(fields)
    clean_fields.pop("video_file", None)
    clean_fields.pop("video_url", None)
    for key, value in clean_fields.items():
        chunks.append(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"{key}\"\r\n"
            "Content-Type: text/plain; charset=utf-8\r\n\r\n".encode("utf-8")
            + encode_form(value).encode("utf-8") + b"\r\n"
        )
    # Use a safe ASCII filename for multipart compatibility while retaining its useful Latin part.
    ascii_stem = video.stem.encode("ascii", "ignore").decode("ascii")
    ascii_stem = re.sub(r"[^A-Za-z0-9._ -]+", "_", ascii_stem).strip(" ._")[:80] or "video"
    upload_name = ascii_stem + (video.suffix.lower() or ".mp4")
    file_header = (
        f"--{boundary}\r\nContent-Disposition: form-data; name=\"video_file\"; filename=\"{upload_name}\"\r\n"
        "Content-Type: video/mp4\r\n\r\n"
    ).encode("ascii")
    closing = f"\r\n--{boundary}--\r\n".encode("ascii")
    prefix = b"".join(chunks) + file_header
    total_length = len(prefix) + video.stat().st_size + len(closing)
    return prefix, closing, total_length


def send_analysis(api_url: str, fields: dict[str, Any], video: Path, boundary: str, state: dict[str, Any]) -> None:
    parsed = urllib.parse.urlsplit(api_url)
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    path = (parsed.path.rstrip("/") if parsed.path else "") + "/api/v1/analyze"
    if parsed.query:
        path += "?" + parsed.query
    prefix, closing, content_length = build_multipart(fields, video, boundary, str(fields.get("job_id", "")))
    connection: http.client.HTTPConnection | http.client.HTTPSConnection
    try:
        if parsed.scheme == "https":
            connection = http.client.HTTPSConnection(parsed.hostname, port, timeout=6 * 60 * 60)
        else:
            connection = http.client.HTTPConnection(parsed.hostname, port, timeout=6 * 60 * 60)
        connection.connect()
        if connection.sock:
            connection.sock.settimeout(6 * 60 * 60)
        connection.putrequest("POST", path)
        connection.putheader("Content-Type", f"multipart/form-data; boundary={boundary}")
        connection.putheader("Content-Length", str(content_length))
        connection.putheader("Accept", "application/json")
        connection.putheader("User-Agent", "VCE-Full-Profile-Benchmark/1.0")
        connection.endheaders()
        connection.send(prefix)
        with video.open("rb") as source:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                connection.send(chunk)
                state["uploaded_bytes"] = state.get("uploaded_bytes", 0) + len(chunk)
        connection.send(closing)
        response = connection.getresponse()
        body = response.read()
        state.update({"http_status": response.status, "http_reason": response.reason, "body": body, "response_headers": dict(response.getheaders())})
    except BaseException as exc:
        state["transport_error"] = repr(exc)
        state["transport_traceback"] = traceback.format_exc()
    finally:
        try:
            connection.close()  # type: ignore[possibly-undefined]
        except Exception:
            pass
        state["done"] = True


def count_transcript_words(payload: dict[str, Any]) -> int | None:
    words = 0
    found = False
    for segment in payload.get("segments", []) if isinstance(payload.get("segments"), list) else []:
        if isinstance(segment, dict):
            text = segment.get("audio_transcript")
            if isinstance(text, str):
                words += len(re.findall(r"\S+", text))
                found = True
    return words if found else None


def stage_metrics(payload: dict[str, Any]) -> tuple[dict[str, float], dict[str, Any]]:
    meta = payload.get("meta", {}) if isinstance(payload.get("meta"), dict) else {}
    timings = meta.get("timings", {}) if isinstance(meta.get("timings"), dict) else {}
    diagnostics = timings.get("stage_diagnostics", {}) if isinstance(timings.get("stage_diagnostics"), dict) else {}
    out: dict[str, float] = {}
    mapping = {
        "scene_detection": diagnostics.get("scene_detection_seconds"),
        "whisper_load": timings.get("whisper", {}).get("load_time") if isinstance(timings.get("whisper"), dict) else None,
        "whisper_inference": timings.get("whisper", {}).get("inference_time") if isinstance(timings.get("whisper"), dict) else None,
        "vlm_load": timings.get("vlm", {}).get("load_time") if isinstance(timings.get("vlm"), dict) else None,
        "vlm_inference": timings.get("vlm", {}).get("inference_time") if isinstance(timings.get("vlm"), dict) else None,
        "apple_ocr": timings.get("apple_ocr", {}).get("inference_time") if isinstance(timings.get("apple_ocr"), dict) else None,
        "ffmpeg_tesseract_ocr": timings.get("ffmpeg_ocr", {}).get("inference_time") if isinstance(timings.get("ffmpeg_ocr"), dict) else None,
        "text_llm": timings.get("text_llm", {}).get("inference_time") if isinstance(timings.get("text_llm"), dict) else None,
        "cpu_frame_prefetch_worker": diagnostics.get("frame_prefetch_worker_seconds"),
        "cpu_frame_prefetch_wait": diagnostics.get("frame_prefetch_wait_seconds"),
        "cpu_whisper_gpu_vlm_overlap": timings.get("parallelism", {}).get("whisper_vlm_overlap_seconds") if isinstance(timings.get("parallelism"), dict) else None,
    }
    text_llm = payload.get("text_llm", {}) if isinstance(payload.get("text_llm"), dict) else {}
    if mapping["text_llm"] is None:
        mapping["text_llm"] = text_llm.get("inference_time")
    for key, value in mapping.items():
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value >= 0:
            out[key] = float(value)
    return out, timings


def runtime_stage_rows(run_key: str, label: str, payload: dict[str, Any], stages: dict[str, float]) -> list[dict[str, Any]]:
    meta = payload.get("meta", {}) if isinstance(payload.get("meta"), dict) else {}
    timing = meta.get("timings", {}) if isinstance(meta.get("timings"), dict) else {}
    whisper_runtime = timing.get("parallelism", {}).get("whisper_runtime", {}) if isinstance(timing.get("parallelism"), dict) else {}
    vlm_runtime = timing.get("vlm", {}).get("runtime", {}) if isinstance(timing.get("vlm"), dict) else {}
    text_runtime = timing.get("text_llm", {}).get("runtime", {}) if isinstance(timing.get("text_llm"), dict) else {}
    ffmpeg_ocr = timing.get("ffmpeg_ocr", {}) if isinstance(timing.get("ffmpeg_ocr"), dict) else {}
    rows: list[dict[str, Any]] = []
    definitions = {
        "scene_detection": ("CPU", "OpenCV scene sampling; CPU path", {}),
        "whisper_load": ("CPU", "Current runtime resolves Whisper to CPU; first model load may be included", whisper_runtime),
        "whisper_inference": ("CPU", "Current runtime pins mlx-whisper to mx.cpu; not PyTorch MPS", whisper_runtime),
        "vlm_load": ("GPU configured", "MLX + Metal; configured Device(gpu), not per-operator proof", vlm_runtime),
        "vlm_inference": ("GPU configured", "MLX + Metal generation stream; no per-operator trace", vlm_runtime),
        "apple_ocr": ("Framework / unknown device", "Apple Vision; runtime does not expose CPU/GPU/ANE attribution", {}),
        "ffmpeg_tesseract_ocr": ("CPU", f"FFmpeg + {ffmpeg_ocr.get('backend', 'Tesseract/unknown')} workers", ffmpeg_ocr),
        "text_llm": ("GPU configured", "Qwen3.5 via MLX worker/Metal GPU target; inspect runtime device fields", text_runtime),
        "cpu_frame_prefetch_worker": ("CPU", "Bounded keyframe decode/resize worker", {}),
        "cpu_frame_prefetch_wait": ("CPU / wait", "Time awaiting keyframe producer; not pure CPU execution", {}),
        "cpu_whisper_gpu_vlm_overlap": ("CPU || GPU", "Runtime-reported overlap between CPU Whisper and MLX/Metal VLM", {}),
    }
    for stage, seconds in stages.items():
        processor, method, evidence = definitions.get(stage, ("unknown", "No classification rule", {}))
        rows.append({
            "run": run_key,
            "profile": label,
            "stage": stage,
            "seconds": round(seconds, 3),
            "processor": processor,
            "acceleration_or_method": method,
            "runtime_evidence_json": json.dumps(evidence, ensure_ascii=False, sort_keys=True, default=str),
        })
    if "process_time" in meta and isinstance(meta["process_time"], (int, float)):
        rows.append({"run": run_key, "profile": label, "stage": "vce_total_process", "seconds": float(meta["process_time"]), "processor": "CPU + GPU stages", "acceleration_or_method": "VCE process_time; not a sum of exclusive device time", "runtime_evidence_json": "{}"})
    return rows


def extract_log_errors(log_text: str, api_error: str | None) -> list[str]:
    patterns = re.compile(r"traceback|\berror\b|exception|failed|fatal|timed?\s*out|command buffer|submissionsignored", re.I)
    found = [line.rstrip() for line in log_text.splitlines() if patterns.search(line)]
    if api_error:
        found.insert(0, "API: " + api_error)
    # Keep context readable; full server log is preserved separately.
    return found[-500:]


def summarize_process_samples(path: Path) -> dict[str, Any]:
    max_cpu = 0.0
    max_rss = 0.0
    max_rss_pid = None
    samples = 0
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if path.exists() else []:
        try:
            obj = json.loads(line)
        except Exception:
            continue
        processes = obj.get("processes", [])
        if not isinstance(processes, list):
            continue
        samples += 1
        cpu_sum = sum(float(p.get("cpu_percent", 0) or 0) for p in processes)
        rss_sum = sum(float(p.get("rss_mib", 0) or 0) for p in processes)
        if cpu_sum > max_cpu:
            max_cpu = cpu_sum
        if rss_sum > max_rss:
            max_rss, max_rss_pid = rss_sum, [p.get("pid") for p in processes]
    return {"process_sample_count": samples, "max_sampled_process_tree_cpu_percent_sum": round(max_cpu, 2), "max_sampled_process_tree_rss_mib_sum": round(max_rss, 2), "pids_at_max_rss_sample": max_rss_pid}


def run_one(
    key: str, label: str, overrides: dict[str, Any], base_fields: dict[str, Any], properties: dict[str, Any],
    api_url: str, video: Path, run_root: Path, log_path: Path | None, port: int, poll_seconds: float,
    pow_cmd: list[str] | None, pow_mode: str, progress_template: str, index: int, total: int,
) -> dict[str, Any]:
    run_dir = run_root / f"{index:02d}_{key}"
    run_dir.mkdir(parents=True, exist_ok=False)
    fields = dict(base_fields)
    fields.update(overrides)
    job_id = f"vcebench_{dt.datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:8]}"
    if "job_id" in properties:
        fields["job_id"] = job_id
    boundary = "----VCEBench" + uuid.uuid4().hex
    state: dict[str, Any] = {"done": False, "http_status": None, "body": b"", "transport_error": None, "uploaded_bytes": 0}
    started = time.monotonic()
    started_at = now_iso()
    log_offset = log_path.stat().st_size if log_path and log_path.exists() else 0
    progress_path = run_dir / "progress_trace.jsonl"
    process_path = run_dir / "process_samples.jsonl"
    power_path = run_dir / "powermetrics_gpu_power.jsonl"
    memory_path = run_dir / "memory_samples.jsonl"
    server_log_delta = run_dir / "server_log_delta.log"
    (run_dir / "request_settings.json").write_text(json.dumps({"profile": key, "label": label, "overrides": overrides, "effective_fields": {k: v for k, v in fields.items() if k not in PROMPT_FIELDS}, "persisted_prompts": "omitted from multipart; running VCE continues to use its persisted prompts"}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    json_write(run_dir / "run_metadata.json", {
        "started_at": started_at, "profile": key, "label": label, "job_id": job_id,
        "video_path_local": str(video), "video_filename": video.name, "video_size_bytes": video.stat().st_size,
        "video_sha256": sha256_file(video), "api_url": api_url, "server_log": str(log_path) if log_path else None,
        "server_log_offset_start": log_offset, "monitor_interval_seconds": poll_seconds,
        "powermetrics_mode": pow_mode, "storage": "local_only",
        "note": "Contains private video-derived output and hardware telemetry; do not commit/upload this folder.",
    })
    # Follow the progress route declared by this running engine; current VCE uses /api/v1/progress/{job_id}.
    encoded_job = urllib.parse.quote(job_id, safe="")
    progress_path = progress_template.replace("{job_id}", encoded_job) if progress_template else "/api/v1/progress/" + encoded_job
    progress_url = api_url.rstrip("/") + (progress_path if progress_path.startswith("/") else "/" + progress_path)
    worker = threading.Thread(target=send_analysis, args=(api_url, fields, video, boundary, state), name=f"vce-upload-{key}", daemon=True)
    print(f"\n[{index}/{total}] {label}: start {started_at}", flush=True)
    print("  Параметры эксперимента:", json.dumps(overrides or {"baseline": True}, ensure_ascii=False), flush=True)
    worker.start()
    listener_roots: set[int] = set()
    last_memory = 0.0
    last_power = 0.0
    last_log_offset = log_offset
    last_progress_signature = None
    last_progress: Any = None
    progress_poll_errors: list[str] = []
    power_records: list[dict[str, Any]] = []
    try:
        while not state["done"]:
            elapsed = round(time.monotonic() - started, 3)
            pids = get_listener_pids(port)
            listener_roots.update(pids)
            processes = process_snapshot(listener_roots | set(pids))
            jsonl_append(process_path, {"at": now_iso(), "elapsed_seconds": elapsed, "listener_pids": pids, "processes": processes})
            try:
                status, progress, raw = http_json(progress_url, timeout=4.0)
                if status == 200:
                    last_progress = progress
                    snapshot = {"at": now_iso(), "elapsed_seconds": elapsed, "http_status": status, "progress": progress}
                    signature = json.dumps(progress, ensure_ascii=False, sort_keys=True, default=str)
                    if signature != last_progress_signature:
                        message = progress.get("message") or progress.get("stage") or progress.get("status") if isinstance(progress, dict) else raw[:300]
                        pct = progress.get("progress", progress.get("percent")) if isinstance(progress, dict) else None
                        print(f"  [{elapsed:8.1f}s] {pct if pct is not None else '…'}% {message or ''}", flush=True)
                        last_progress_signature = signature
                else:
                    snapshot = {"at": now_iso(), "elapsed_seconds": elapsed, "http_status": status, "response": raw[:1000]}
            except Exception as exc:
                progress_poll_errors.append(repr(exc))
                snapshot = {"at": now_iso(), "elapsed_seconds": elapsed, "poll_error": repr(exc)}
            jsonl_append(progress_path, snapshot)
            if time.monotonic() - last_memory >= 15:
                mem = memory_snapshot()
                jsonl_append(memory_path, {"at": now_iso(), "elapsed_seconds": elapsed, **mem})
                last_memory = time.monotonic()
            if pow_cmd and time.monotonic() - last_power >= 12:
                rc, out, err = run_command(pow_cmd, timeout=12)
                record = {"at": now_iso(), "elapsed_seconds": elapsed, "returncode": rc, "status": "sampled" if rc == 0 else "unavailable_or_permission_denied", "mode": pow_mode, "parsed": parse_gpu_sample(out), "stdout": out[:10000], "stderr": err[:3000], "scope": "system-wide; not attributable to the VCE PID"}
                jsonl_append(power_path, record)
                power_records.append(record)
                last_power = time.monotonic()
            elif not pow_cmd and time.monotonic() - last_power >= 60:
                record = {"at": now_iso(), "elapsed_seconds": elapsed, "status": pow_mode, "scope": "not sampled"}
                jsonl_append(power_path, record)
                power_records.append(record)
                last_power = time.monotonic()
            last_log_offset, _ = drain_server_log(log_path, last_log_offset, server_log_delta)
            time.sleep(max(0.5, poll_seconds))
    except KeyboardInterrupt:
        state["transport_error"] = state.get("transport_error") or "KeyboardInterrupt; upload/analysis may still be running server-side"
        json_write(run_dir / "interrupted.json", {"at": now_iso(), "job_id": job_id, "note": "Check VCE UI before starting another analysis."})
        raise
    finally:
        worker.join(timeout=2)
        last_log_offset, _ = drain_server_log(log_path, last_log_offset, server_log_delta)

    elapsed_total = time.monotonic() - started
    body_bytes = state.get("body") if isinstance(state.get("body"), bytes) else b""
    (run_dir / "response.json").write_bytes(body_bytes)
    body_text = body_bytes.decode("utf-8", "replace")
    try:
        payload = json.loads(body_text) if body_text else {}
    except Exception as exc:
        payload = {"_response_parse_error": repr(exc), "_raw": body_text[:10000]}
    if not isinstance(payload, dict):
        payload = {"_response": payload}
    meta = payload.get("meta", {}) if isinstance(payload.get("meta"), dict) else {}
    text_llm = payload.get("text_llm", {}) if isinstance(payload.get("text_llm"), dict) else {}
    timings, raw_timings = stage_metrics(payload)
    stage_rows = runtime_stage_rows(key, label, payload, timings)
    json_write(run_dir / "stage_timings.json", raw_timings)
    with (run_dir / "stage_timings.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=["stage", "seconds"])
        writer.writeheader()
        for name, seconds in timings.items():
            writer.writerow({"stage": name, "seconds": round(seconds, 3)})
    api_error = None
    if state.get("transport_error"):
        api_error = str(state["transport_error"])
    elif state.get("http_status") != 200:
        api_error = f"HTTP {state.get('http_status')} {state.get('http_reason', '')}: {body_text[:2000]}"
    elif payload.get("detail") and not meta:
        api_error = str(payload.get("detail"))
    elif text_llm.get("status") == "failed" and text_llm.get("error"):
        api_error = "Qwen3.5 post-processing: " + str(text_llm.get("error"))
    log_text = server_log_delta.read_text(encoding="utf-8", errors="replace") if server_log_delta.exists() else ""
    errors = extract_log_errors(log_text, api_error)
    errors.extend("Progress polling: " + item for item in progress_poll_errors[-30:])
    ffmpeg_message = None
    ffmpeg_info = raw_timings.get("ffmpeg_ocr", {}) if isinstance(raw_timings.get("ffmpeg_ocr"), dict) else {}
    if ffmpeg_info.get("message"):
        ffmpeg_message = "FFmpeg OCR: " + str(ffmpeg_info.get("message"))
    if ffmpeg_message and ffmpeg_message not in errors:
        errors.append(ffmpeg_message)
    (run_dir / "errors.log").write_text("\n".join(errors) + ("\n" if errors else "No API/server error markers were captured.\n"), encoding="utf-8")
    json_write(run_dir / "errors.json", {"error_count": len(errors), "errors": errors, "transport_error": state.get("transport_error"), "http_status": state.get("http_status"), "text_llm_error": text_llm.get("error")})
    process_summary = summarize_process_samples(process_path)
    gpu_good = [r.get("parsed", {}).get("gpu_active_residency_percent") for r in power_records if r.get("status") == "sampled" and isinstance(r.get("parsed", {}).get("gpu_active_residency_percent"), (int, float))]
    status = "completed" if state.get("http_status") == 200 and isinstance(meta, dict) and meta else "error"
    record = {
        "profile": key, "label": label, "status": status, "started_at": started_at, "finished_at": now_iso(),
        "client_wall_seconds": round(elapsed_total, 3), "vce_process_seconds": meta.get("process_time"),
        "scene_count": meta.get("scene_count"), "transcript_words": count_transcript_words(payload),
        "http_status": state.get("http_status"), "http_reason": state.get("http_reason"),
        "transport_error": state.get("transport_error"), "error_count": len(errors), "error_excerpt": errors[:5],
        "stage_seconds": timings, "process_summary": process_summary,
        "powermetrics_sample_count": len(gpu_good),
        "gpu_residency_system_avg_percent": round(statistics.mean(gpu_good), 2) if gpu_good else None,
        "gpu_residency_system_max_percent": round(max(gpu_good), 2) if gpu_good else None,
        "result_directory": str(run_dir), "overrides": overrides,
        "mlx_whisper_flag_note": "In current source this flag validates the checkpoint; load_whisper_model already returns mlx-whisper on mx.cpu even when the flag is false." if key in {"mlx_whisper_flag", "all_experiments"} else None,
    }
    json_write(run_dir / "run_summary.json", record)
    with (run_dir / "stage_rows.json").open("w", encoding="utf-8") as handle:
        json.dump(stage_rows, handle, ensure_ascii=False, indent=2)
    print(f"  -> {status}; wall={elapsed_total:.1f}s; VCE={meta.get('process_time', '—')}s; scenes={meta.get('scene_count', '—')}; errors={len(errors)}", flush=True)
    print(f"     local: {run_dir}", flush=True)
    return record


def write_csv(path: Path, rows: list[dict[str, Any]], columns: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if columns is None:
        columns = list(dict.fromkeys(k for row in rows for k in row.keys()))
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            safe = {k: json.dumps(v, ensure_ascii=False, default=str) if isinstance(v, (dict, list)) else v for k, v in row.items()}
            writer.writerow(safe)


def make_markdown(run_id: str, manifest: dict[str, Any], results: list[dict[str, Any]], stage_rows: list[dict[str, Any]]) -> str:
    lines = [
        "# VCE Full Profile Benchmark", "", f"- Run: `{run_id}`", f"- Finished: {now_iso()}",
        "- Engine: VideoContext Engine v3.19; repository distribution version at script publication: 0.2.5",
        f"- Machine: `{manifest.get('machine')}` / `{manifest.get('platform')}`; unified memory: {manifest.get('memory_gib') or 'unknown'} GiB",
        f"- Input: `{manifest.get('video_filename')}`; {manifest.get('video_size_mib')} MiB; duration: {manifest.get('video_duration_seconds') or 'unknown'} s",
        "- Storage: local only; no video, transcript, raw response or telemetry is uploaded to GitHub.", "",
        "## Сравнение прогонов", "",
        "| Профиль | Статус | Wall, с | VCE, с | Сцен | Слов Whisper | VLM, с | Whisper, с | Apple OCR, с | FFmpeg OCR, с | Qwen3.5, с | CPU||GPU overlap, с | Ошибки |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    def val(item: dict[str, Any], key: str) -> str:
        x = item.get("stage_seconds", {}).get(key)
        return f"{x:.1f}" if isinstance(x, (int, float)) else "—"
    for r in results:
        lines.append("| {label} | {status} | {wall} | {vce} | {scenes} | {words} | {vlm} | {whisper} | {apple} | {ffmpeg} | {llm} | {overlap} | {errors} |".format(
            label=r.get("label", r.get("profile")), status=r.get("status"),
            wall=f"{r.get('client_wall_seconds'):.1f}" if isinstance(r.get("client_wall_seconds"), (int,float)) else "—",
            vce=f"{r.get('vce_process_seconds'):.1f}" if isinstance(r.get("vce_process_seconds"), (int,float)) else "—",
            scenes=r.get("scene_count", "—"), words=r.get("transcript_words", "—"),
            vlm=val(r,"vlm_inference"), whisper=val(r,"whisper_inference"), apple=val(r,"apple_ocr"), ffmpeg=val(r,"ffmpeg_tesseract_ocr"),
            llm=val(r,"text_llm"), overlap=val(r,"cpu_whisper_gpu_vlm_overlap"), errors=r.get("error_count", 0)))
    lines += ["", "## Мониторинг CPU / RAM / GPU", "", "| Профиль | CPU процесса, max % | RSS дерева, max MiB | GPU samples | GPU residency avg/max, %* |", "|---|---:|---:|---:|---:|"]
    for r in results:
        ps = r.get("process_summary", {})
        avg, maxv = r.get("gpu_residency_system_avg_percent"), r.get("gpu_residency_system_max_percent")
        gpu = f"{avg}/{maxv}" if avg is not None else "—"
        lines.append(f"| {r.get('profile')} | {ps.get('max_sampled_process_tree_cpu_percent_sum','—')} | {ps.get('max_sampled_process_tree_rss_mib_sum','—')} | {r.get('powermetrics_sample_count',0)} | {gpu} |")
    lines += ["", "*GPU residency собирается `powermetrics` на уровне всей системы и не может быть приписана конкретно PID движка. Если permission отсутствует, значение будет пустым.*", "", "## Что реально выполняется на каком устройстве", "",
        "| Этап | Путь исполнения по текущему коду | Ускорение / доказательство |", "|---|---|---|",
        "| Детекция сцен | CPU | OpenCV; stage timer `scene_detection_seconds` |",
        "| Whisper | CPU | `mlx-whisper`, закреплённый на `mx.cpu`; MPS не используется для Whisper inference в текущем runtime, несмотря на подпись UI |",
        "| Qwen3-VL | GPU target | MLX + Metal, явный `Device(gpu)` и GPU stream smoke test; это конфигурация/stream evidence, не доказательство каждого GPU operator |",
        "| Apple Vision OCR | аппаратный backend не раскрыт | Apple Vision API; нельзя достоверно приписать CPU, GPU или ANE по текущей телеметрии |",
        "| FFmpeg/Tesseract OCR | CPU | FFmpeg + Tesseract CLI и ограниченные CPU workers, если фильтр/бинарники доступны |",
        "| Qwen3.5 text post-processing | GPU target | MLX worker/Metal; проверить runtime fields конкретного ответа, без per-operator attribution |",
        "| Keyframe prefetch | CPU | bounded CPU decode/resize worker; метрики worker/wait seconds |",
        "| Whisper + VLM overlap | CPU || GPU | runtime возвращает `whisper_vlm_overlap_seconds`; измеренное перекрытие пишется в таблицу этапов |",
        "", "## Важные оговорки", "",
        "- `enable_stage_timing` включён во всех прогонах как измерительный инструмент; сам по себе он не ускоряет распознавание.",
        "- `enable_mlx_whisper` в текущем `VideoContextEngine_v3.19.py` вызывает preflight-проверку модели, но не меняет backend: `resolve_whisper_device()` возвращает CPU, а `load_whisper_model()` создаёт MLX CPU adapter и при выключенном флаге. Не трактуйте соответствующий A/B-прогон как сравнение MPS vs MLX.",
        "- `whisper_acceleration` — поле настроек/UI; текущая реализация закрепляет Whisper на CPU stream. Очистка `torch.mps` cache в helper-функции не означает MPS inference.",
        "- WER/CER не рассчитываются без размеченного эталонного текста. Число слов и сцен — только coverage proxies, не оценка точности.",
        "- Эксперименты one-factor-at-a-time: адаптивные кадры с верхним пределом 2; OCR cache; MLX Whisper validation flag; fast scene detection (1 fps); в конце combined all-on.",
        "- VCE может возвращать частичный результат и предупреждения; изучите `errors.log`, `server_log_delta.log`, `response.json` каждого профиля.",
        "", "## Файлы", "", "- `run_summary.csv` — сводная таблица.", "- `stage_comparison.csv` — этапы, секунды, CPU/GPU class и backend evidence.", "- `device_monitoring.csv` — CPU/RSS и системная GPU телеметрия.", "- `errors.csv` — ошибки/предупреждения по каждому прогону.", "- Подпапки каждого прогона содержат полный JSON ответ и приватную телеметрию.", ""]
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--video", type=Path, default=DEFAULT_VIDEO, help="Исходный MP4.")
    parser.add_argument("--project", type=Path, default=DEFAULT_PROJECT, help="Каталог установленной копии VCE.")
    parser.add_argument("--api-url", default=DEFAULT_API, help="Локальный API VCE.")
    parser.add_argument("--out-root", type=Path, default=DEFAULT_OUTPUT, help="Каталог приватных результатов вне Git checkout.")
    parser.add_argument("--server-log", default=None, help="Явный путь к логу VCE.")
    parser.add_argument("--interval", type=float, default=2.0, help="Частота опроса прогресса/процессов, секунд.")
    parser.add_argument("--no-combined", action="store_true", help="Пропустить заключительный all-experimental прогон.")
    parser.add_argument("--no-powermetrics", action="store_true", help="Не пытаться читать системную GPU telemetry.")
    parser.add_argument("--dry-run", action="store_true", help="Проверить настройки и показать план без отправки видео.")
    args = parser.parse_args()

    if platform.system() != "Darwin" or platform.machine().lower() not in {"arm64", "aarch64"}:
        raise RuntimeError(f"Требуется macOS на Apple Silicon; обнаружено {platform.system()}/{platform.machine()}.")
    video = args.video.expanduser().resolve()
    project = args.project.expanduser().resolve()
    api_url = args.api_url.rstrip("/")
    settings_path = project / "videocontext_settings.json"
    if not video.is_file():
        raise RuntimeError(f"Исходное видео не найдено: {video}")
    if not settings_path.is_file():
        raise RuntimeError(f"Не найден файл настроек {settings_path}. Установите/запустите VCE из README.")
    if not maybe_start_app(api_url):
        raise RuntimeError(f"VCE API не отвечает на {api_url}. Откройте VideoContext Engine.app и проверьте ~/Library/Logs/VideoContext Engine/server.log.")

    port = urllib.parse.urlsplit(api_url).port or (443 if api_url.startswith("https:") else 80)
    properties, progress_template, _ = load_api_schema(api_url)
    active_status, active_settings, raw_active = http_json(api_url + "/api/v1/ui-settings", timeout=10)
    if active_status != 200 or not isinstance(active_settings, dict):
        raise RuntimeError(f"GET /api/v1/ui-settings вернул HTTP {active_status}: {raw_active[:1000]}")
    local_settings = read_local_settings(settings_path)
    comparable = sorted((set(local_settings) & set(active_settings)) - PROMPT_FIELDS - DYNAMIC_SETTINGS)
    differences = {k: {"settings_file": local_settings[k], "active_server": active_settings[k]} for k in comparable if local_settings[k] != active_settings[k]}
    memory_bytes = get_memory_bytes()
    base_fields, missing_fields = build_base_fields(properties, active_settings, memory_bytes)
    plan = build_plan(base_fields, properties, include_combined=not args.no_combined)
    video_duration = ffprobe_duration(video)
    run_id = dt.datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    run_root = args.out_root.expanduser().resolve() / run_id
    # Explicitly guard the user's Git checkout from accidental benchmark artefacts.
    try:
        run_root.relative_to(project)
    except ValueError:
        pass
    else:
        raise RuntimeError("Папка результатов должна быть вне checkout проекта; используйте ~/Downloads/VCE_Full_Profile_Benchmark.")

    log_path = pick_log(args.server_log)
    pow_cmd, pow_mode = (None, "disabled_by_user") if args.no_powermetrics else powermetrics_command()
    manifest = {
        "run_id": run_id, "created_at": now_iso(), "platform": platform.platform(), "machine": platform.machine(),
        "memory_bytes": memory_bytes, "memory_gib": round(memory_bytes / (1024 ** 3), 2) if memory_bytes else None,
        "video_filename": video.name, "video_path_local": str(video), "video_size_bytes": video.stat().st_size,
        "video_size_mib": round(video.stat().st_size / (1024 ** 2), 2), "video_duration_seconds": video_duration,
        "video_sha256": sha256_file(video), "project_path": str(project), "settings_path": str(settings_path),
        "settings_sha256": sha256_file(settings_path), "api_url": api_url,
        "active_settings_differences_vs_file": differences, "missing_openapi_fields": missing_fields,
        "ffmpeg_ocr_available": active_settings.get("ffmpeg_ocr_available"), "ffmpeg_ocr_reason": active_settings.get("ffmpeg_ocr_reason"),
        "base_profile": base_fields, "plan": [{"key": k, "label": label, "overrides": changes} for k, label, changes in plan],
        "progress_path_template": progress_template or None, "powermetrics_mode": pow_mode,
        "note": "Settings are read-only. API active settings are authoritative. Raw responses and telemetry remain local.",
    }
    if args.dry_run:
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        print("\nПлан:")
        for i, (key, label, overrides) in enumerate(plan, 1):
            print(f"{i}. {key}: {label} — {json.dumps(overrides, ensure_ascii=False)}")
        print("DRY RUN: видео не отправлялось, файлы не менялись.")
        return 0

    # Avoid overlapping analysis runs on the same engine / unified-memory GPU.
    server_log = log_path
    if server_log and server_log.exists():
        tail = server_log.read_text(encoding="utf-8", errors="replace")[-2_000_000:]
        job_ids = list(dict.fromkeys(re.findall(r"/api/v1/progress/(ui_[A-Za-z0-9_-]+)", tail)))[-20:]
        for old_job in reversed(job_ids):
            try:
                _, progress, _ = http_json(api_url + "/api/v1/progress/" + urllib.parse.quote(old_job, safe=""), timeout=4)
                if isinstance(progress, dict) and progress.get("status") == "running":
                    raise RuntimeError(f"VCE уже выполняет задание {old_job}: {progress.get('message','')}. Дождитесь завершения перед benchmark.")
            except RuntimeError:
                raise
            except Exception:
                pass

    run_root.mkdir(parents=True, exist_ok=False)
    json_write(run_root / "manifest.json", manifest)
    json_write(run_root / "local_settings_snapshot.json", local_settings)
    json_write(run_root / "active_server_settings_snapshot.json", active_settings)
    print("=" * 78)
    print("VCE FULL PROFILE BENCHMARK — macOS / Apple Silicon")
    print("Источник:", video)
    print("Видео: %.2f MiB; длительность: %s s" % (manifest["video_size_mib"], video_duration if video_duration is not None else "unknown"))
    print("Unified memory:", manifest["memory_gib"], "GiB; profile resolution:", base_fields.get("vlm_resolution"))
    print("API:", api_url, "| server log:", log_path or "not found")
    print("powermetrics:", pow_mode, "| OCR FFmpeg available:", active_settings.get("ffmpeg_ocr_available"))
    if differences:
        print("WARN: локальный settings.json отличается от live API; для тестов используется active API settings.")
        json_write(run_root / "settings_mismatch_warning.json", differences)
    if missing_fields:
        print("WARN: OpenAPI не объявил некоторые поля оптимального профиля:", ", ".join(missing_fields))
    print("Все прогоны выполняются последовательно; пользовательские настройки не сохраняются и не перезаписываются.")
    print("Полные результаты приватны и остаются на диске. Не отправлять output-папку в GitHub.")
    print("=" * 78, flush=True)

    results: list[dict[str, Any]] = []
    all_stage_rows: list[dict[str, Any]] = []
    for index, (key, label, overrides) in enumerate(plan, 1):
        try:
            record = run_one(key, label, overrides, base_fields, properties, api_url, video, run_root, log_path, port, args.interval, pow_cmd, pow_mode, progress_template, index, len(plan))
        except KeyboardInterrupt:
            print("\nПрервано пользователем. Проверьте VCE UI: серверная задача может ещё работать.", file=sys.stderr)
            raise
        except Exception as exc:
            error = {"profile": key, "label": label, "status": "runner_error", "error": repr(exc), "traceback": traceback.format_exc(), "finished_at": now_iso()}
            json_write(run_root / f"{index:02d}_{key}_runner_error.json", error)
            record = {"profile": key, "label": label, "status": "runner_error", "error_count": 1, "error_excerpt": [repr(exc)], "client_wall_seconds": None, "stage_seconds": {}, "process_summary": {}, "powermetrics_sample_count": 0}
        results.append(record)
        stage_path = Path(record.get("result_directory", "")) / "stage_rows.json"
        if stage_path.is_file():
            try:
                all_stage_rows.extend(json.loads(stage_path.read_text(encoding="utf-8")))
            except Exception:
                pass
        json_write(run_root / "progress_summary.json", {"finished_cases": len(results), "total_cases": len(plan), "latest_profile": key, "latest_status": record.get("status"), "updated_at": now_iso()})
        if index == 1 and record.get("status") != "completed":
            print("Baseline не завершился успешно; оставшиеся эксперименты отменены, диагностика сохранена.", file=sys.stderr)
            break

    write_csv(run_root / "run_summary.csv", results)
    write_csv(run_root / "stage_comparison.csv", all_stage_rows, ["run", "profile", "stage", "seconds", "processor", "acceleration_or_method", "runtime_evidence_json"])
    monitor_rows = []
    error_rows = []
    for item in results:
        ps = item.get("process_summary", {})
        monitor_rows.append({"profile": item.get("profile"), "process_samples": ps.get("process_sample_count"), "max_process_tree_cpu_percent_sum": ps.get("max_sampled_process_tree_cpu_percent_sum"), "max_process_tree_rss_mib_sum": ps.get("max_sampled_process_tree_rss_mib_sum"), "powermetrics_sample_count": item.get("powermetrics_sample_count"), "gpu_system_avg_residency_percent": item.get("gpu_residency_system_avg_percent"), "gpu_system_max_residency_percent": item.get("gpu_residency_system_max_percent"), "note": "GPU power/residency is system-wide, not PID-attributed."})
        if item.get("error_count") or item.get("error_excerpt"):
            error_rows.append({"profile": item.get("profile"), "status": item.get("status"), "error_count": item.get("error_count"), "errors": "\n".join(item.get("error_excerpt", [])), "result_directory": item.get("result_directory")})
    write_csv(run_root / "device_monitoring.csv", monitor_rows)
    write_csv(run_root / "errors.csv", error_rows, ["profile", "status", "error_count", "errors", "result_directory"])
    final_summary = {
        "run_id": run_id, "finished_at": now_iso(), "video_filename": video.name,
        "total_profiles_planned": len(plan), "profiles_completed": sum(1 for x in results if x.get("status") == "completed"),
        "profiles_failed": sum(1 for x in results if x.get("status") != "completed"),
        "storage": "local_only", "result_directory": str(run_root),
        "results": results, "files": ["run_summary.csv", "stage_comparison.csv", "device_monitoring.csv", "errors.csv", "summary.md"],
    }
    json_write(run_root / "summary.json", final_summary)
    (run_root / "summary.md").write_text(make_markdown(run_id, manifest, results, all_stage_rows), encoding="utf-8")
    print("\n" + "=" * 78)
    print("BENCHMARK COMPLETE")
    print("Результаты:", run_root)
    print("Сводная таблица:", run_root / "run_summary.csv")
    print("Этапы / CPU-GPU:", run_root / "stage_comparison.csv")
    print("Мониторинг:", run_root / "device_monitoring.csv")
    print("Ошибки:", run_root / "errors.csv")
    print("Отчёт:", run_root / "summary.md")
    print(f"Успешно: {final_summary['profiles_completed']} / {final_summary['total_profiles_planned']}; с ошибками: {final_summary['profiles_failed']}")
    print("Видеофайл, transcript и полный response никуда не отправлялись.")
    return 0 if final_summary["profiles_failed"] == 0 else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as exc:
        print(f"FATAL: {exc}", file=sys.stderr)
        raise SystemExit(2)
