#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Install strict, multi-language recognition controls into VideoContext Engine v3.19."""
from __future__ import annotations

import argparse
import ast
import difflib
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Tuple

ENGINE = Path("VideoContextEngine_v3.19.py")
UI = Path("videocontext_web_ui.html")
CONFIG = Path("videocontext_settings.json")
MARKER = "# VCE_RECOGNITION_LANGUAGES_V1"
UI_MARKER = "<!-- VCE_RECOGNITION_LANGUAGES_V1 -->"

HELPERS = r'''# VCE_RECOGNITION_LANGUAGES_V1
_VCE_RECOGNITION_LANGUAGE_CATALOG = {
    "ru": {"name": "Русский", "vision": "ru-RU", "tesseract": "rus"},
    "en": {"name": "English", "vision": "en-US", "tesseract": "eng"},
    "pt": {"name": "Português", "vision": "pt-BR", "tesseract": "por"},
    "es": {"name": "Español", "vision": "es-ES", "tesseract": "spa"},
    "fr": {"name": "Français", "vision": "fr-FR", "tesseract": "fra"},
    "de": {"name": "Deutsch", "vision": "de-DE", "tesseract": "deu"},
    "it": {"name": "Italiano", "vision": "it-IT", "tesseract": "ita"},
    "nl": {"name": "Nederlands", "vision": "nl-NL", "tesseract": "nld"},
    "pl": {"name": "Polski", "vision": "pl-PL", "tesseract": "pol"},
    "tr": {"name": "Türkçe", "vision": "tr-TR", "tesseract": "tur"},
    "uk": {"name": "Українська", "vision": "uk-UA", "tesseract": "ukr"},
    "zh": {"name": "中文（简体）", "vision": "zh-Hans", "tesseract": "chi_sim"},
    "ja": {"name": "日本語", "vision": "ja-JP", "tesseract": "jpn"},
    "ko": {"name": "한국어", "vision": "ko-KR", "tesseract": "kor"},
    "ar": {"name": "العربية", "vision": "ar-SA", "tesseract": "ara"},
}
_VCE_DEFAULT_RECOGNITION_LANGUAGES = ["ru", "en"]


def _vce_normalize_recognition_languages(value):
    """Normalize a user selection and reject unknown language identifiers."""
    if isinstance(value, str):
        raw = value.strip()
        if raw.startswith("["):
            try:
                value = json.loads(raw)
            except Exception as exc:
                raise ValueError("recognition_languages должен быть JSON-массивом") from exc
        else:
            value = [part.strip() for part in raw.split(",") if part.strip()]
    if not isinstance(value, (list, tuple)):
        raise ValueError("recognition_languages должен быть списком языковых кодов")
    result = []
    for item in value:
        code = str(item or "").strip().lower()
        if code not in _VCE_RECOGNITION_LANGUAGE_CATALOG:
            raise ValueError("Неподдерживаемый язык распознавания: " + code)
        if code not in result:
            result.append(code)
    if not result:
        raise ValueError("Выберите хотя бы один язык распознавания")
    return result


def _vce_legacy_apple_languages(value):
    """Migrate legacy Vision locale preferences to the shared language codes."""
    locale_to_code = {
        data["vision"].lower(): code
        for code, data in _VCE_RECOGNITION_LANGUAGE_CATALOG.items()
    }
    result = []
    for locale in value if isinstance(value, list) else []:
        code = locale_to_code.get(str(locale).strip().lower())
        if code and code not in result:
            result.append(code)
    return result or list(_VCE_DEFAULT_RECOGNITION_LANGUAGES)


def _vce_whisper_supported_languages():
    """Return language codes implemented by the installed Whisper tokenizer."""
    try:
        from whisper.tokenizer import LANGUAGES
        return set(LANGUAGES.keys())
    except Exception:
        try:
            from mlx_whisper.tokenizer import LANGUAGES
            return set(LANGUAGES.keys())
        except Exception:
            return set()


def _vce_vision_supported_languages():
    """Ask the installed macOS Vision framework for real OCR locale support."""
    try:
        import Vision
        request = Vision.VNRecognizeTextRequest.alloc().init()
        response = request.supportedRecognitionLanguagesAndReturnError_(None)
        values = response[0] if isinstance(response, tuple) else response
        return {str(item) for item in (values or [])}
    except Exception as exc:
        print("[VCE languages] Vision availability query failed: " + str(exc)[:240])
        return set()


def _vce_tesseract_installed_languages():
    """Read installed traineddata names from the local Tesseract binary."""
    binary = _vce_which_binary("tesseract")
    if not binary:
        return set()
    try:
        proc = subprocess.run(
            [binary, "--list-langs"], capture_output=True, text=True,
            timeout=15, check=False,
        )
        raw = (proc.stdout or "") + "\n" + (proc.stderr or "")
        found = {
            line.strip() for line in raw.splitlines()
            if re.fullmatch(r"[A-Za-z0-9_]+", line.strip())
        }
        return {item for item in found if item.lower() not in {"list", "available"}}
    except Exception as exc:
        print("[VCE languages] Tesseract language query failed: " + str(exc)[:240])
        return set()


def _vce_recognition_language_status():
    """Return per-engine availability; selection remains independent of missing backends."""
    whisper_languages = _vce_whisper_supported_languages()
    vision_languages = _vce_vision_supported_languages()
    tesseract_languages = _vce_tesseract_installed_languages()
    rows = []
    for code, item in _VCE_RECOGNITION_LANGUAGE_CATALOG.items():
        rows.append({
            "code": code,
            "name": item["name"],
            "whisper": code in whisper_languages,
            "vision": item["vision"] in vision_languages,
            "tesseract": item["tesseract"] in tesseract_languages,
        })
    return rows


def _vce_effective_vision_locales(recognition_languages=None):
    requested = _vce_normalize_recognition_languages(
        setting("recognition_languages", _VCE_DEFAULT_RECOGNITION_LANGUAGES)
        if recognition_languages is None else recognition_languages
    )
    available = _vce_vision_supported_languages()
    return [
        _VCE_RECOGNITION_LANGUAGE_CATALOG[code]["vision"]
        for code in requested
        if _VCE_RECOGNITION_LANGUAGE_CATALOG[code]["vision"] in available
    ]


def _vce_language_policy_prompt(recognition_languages=None):
    requested = _vce_normalize_recognition_languages(
        setting("recognition_languages", _VCE_DEFAULT_RECOGNITION_LANGUAGES)
        if recognition_languages is None else recognition_languages
    )
    names = [
        _VCE_RECOGNITION_LANGUAGE_CATALOG[code]["name"]
        for code in requested
    ]
    primary = _VCE_RECOGNITION_LANGUAGE_CATALOG[requested[0]]["name"]
    return (
        "\n\nСТРОГАЯ ЯЗЫКОВАЯ ПОЛИТИКА VCE. Разрешённые языки входной речи и экранного текста: "
        + ", ".join(names) + ". Язык аналитических описаний и итогового конспекта: " + primary + ". "
        "Не распознавай, не цитируй и не реконструируй речь или надписи на языках вне этого списка. "
        "Не угадывай нечитаемый текст, имена, числа, команды или термины. Если фрагмент нельзя уверенно прочитать "
        "на разрешённом языке, пропусти его или явно отметь как неразборчивый. Сохраняй точное написание "
        "только для фактически различимых источников; не переводи и не переписывай исходные OCR/ASR-данные."
    )


def _vce_transcribe_allowed_language_chunks(
    model, media_path, duration_seconds, recognition_languages, word_timestamps=True,
    chunk_seconds=30,
):
    """Transcribe separate <=30s audio chunks and retain only selected-language chunks."""
    requested = _vce_normalize_recognition_languages(recognition_languages)
    supported = _vce_whisper_supported_languages()
    allowed = [code for code in requested if code in supported]
    if not allowed:
        return {"segments": [], "language": None}, (
            "ASR пропущен: ни один выбранный язык не поддерживается установленным Whisper."
        )
    ffmpeg = _vce_which_binary("ffmpeg")
    if not ffmpeg:
        raise RuntimeError("ASR с ограничением языков требует FFmpeg для нарезки аудио на блоки.")
    total = max(0.0, float(duration_seconds or 0.0))
    if total <= 0:
        return {"segments": [], "language": None}, "ASR пропущен: длительность аудио не определена."
    merged = []
    detected = []
    rejected = []
    with tempfile.TemporaryDirectory(prefix="vce_asr_language_chunks_") as work_dir:
        for index, start in enumerate(float(x) for x in range(0, int(total) + 1, int(chunk_seconds))):
            length = min(float(chunk_seconds), total - start)
            if length <= 0.25:
                continue
            wav_path = str(Path(work_dir) / ("audio_%05d.wav" % index))
            extract = subprocess.run(
                [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error",
                 "-ss", "%.3f" % start, "-i", str(media_path), "-t", "%.3f" % length,
                 "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", "-y", wav_path],
                capture_output=True, text=True, timeout=180, check=False,
            )
            if extract.returncode != 0 or not Path(wav_path).is_file() or Path(wav_path).stat().st_size < 2048:
                detail = ((extract.stderr or "").strip().splitlines()[-1:] or ["нет аудиоданных"])[0]
                continue
            result = model.transcribe(
                wav_path,
                language=allowed[0] if len(allowed) == 1 else None,
                word_timestamps=bool(word_timestamps),
                condition_on_previous_text=False,
                temperature=0.0,
                compression_ratio_threshold=1.8,
                verbose=False,
            )
            language = str((result or {}).get("language") or "").strip().lower()
            if language not in allowed:
                rejected.append(language or "unknown")
                continue
            if language not in detected:
                detected.append(language)
            for source_segment in (result or {}).get("segments", []) or []:
                segment = dict(source_segment)
                segment["start"] = round(float(segment.get("start", 0.0) or 0.0) + start, 3)
                segment["end"] = round(float(segment.get("end", 0.0) or 0.0) + start, 3)
                segment["language"] = language
                words = segment.get("words")
                if isinstance(words, list):
                    adjusted_words = []
                    for source_word in words:
                        if not isinstance(source_word, dict):
                            continue
                        word = dict(source_word)
                        for key in ("start", "end"):
                            if word.get(key) is not None:
                                word[key] = round(float(word[key]) + start, 3)
                        adjusted_words.append(word)
                    segment["words"] = adjusted_words
                merged.append(segment)
    merged.sort(key=lambda item: (float(item.get("start", 0.0)), float(item.get("end", 0.0))))
    note_parts = []
    if rejected:
        note_parts.append("Пропущены аудиоблоки с неразрешённым языком: " + ", ".join(sorted(set(rejected))))
    if not merged and not note_parts:
        note_parts.append("Whisper не вернул сегментов для выбранных языков.")
    return {"segments": merged, "language": detected[0] if len(detected) == 1 else None,
            "detected_languages": detected}, "; ".join(note_parts)


def apple_vision_ocr(image: Image.Image, recognition_languages=None) -> str:
'''

OLD_APPLE_BODY = '''    try:
        rows = ocrmac.OCR(
            image,
            recognition_level=str(setting("apple_ocr_recognition_level", "accurate")),
            language_preference=setting("apple_ocr_languages", ["ru-RU", "en-US"]),
            confidence_threshold=float(setting("apple_ocr_confidence", 0.30)),
            detail=True,
        ).recognize()
    except ValueError:
        # Some macOS/Vision combinations may not support one of the requested languages.
        rows = ocrmac.OCR(
            image,
            recognition_level="accurate",
            language_preference=None,
            confidence_threshold=0.30,
            detail=True,
        ).recognize()
'''
NEW_APPLE_BODY = '''    try:
        language_preference = _vce_effective_vision_locales(recognition_languages)
        if not language_preference:
            print("[VCE OCR] Apple Vision пропущен: среди выбранных языков нет установленных в Vision.")
            return ""
        rows = ocrmac.OCR(
            image,
            recognition_level=str(setting("apple_ocr_recognition_level", "accurate")),
            language_preference=language_preference,
            confidence_threshold=float(setting("apple_ocr_confidence", 0.30)),
            detail=True,
        ).recognize()
    except Exception as exc:
        print("[VCE OCR] Apple Vision не выполнил распознавание в выбранных языках: " + str(exc)[:300])
        return ""
'''

NEW_TESSERACT_FUNCTIONS = r'''# VCE_RECOGNITION_LANGUAGES_TESSERACT_V1

def _vce_detect_ffmpeg_ocr_backend(recognition_languages=None) -> tuple[str, str, str]:
    """Use only selected Tesseract traineddata that is actually installed locally."""
    ffmpeg = _vce_which_binary("ffmpeg")
    tesseract = _vce_which_binary("tesseract")
    if not ffmpeg:
        return "unavailable", "", "FFmpeg не найден; Tesseract OCR отключён, Apple Vision может продолжить работу."
    if not tesseract:
        return "unavailable", "", "Tesseract CLI не найден; Tesseract OCR отключён без языкового fallback."
    selected = _vce_normalize_recognition_languages(
        setting("recognition_languages", _VCE_DEFAULT_RECOGNITION_LANGUAGES)
        if recognition_languages is None else recognition_languages
    )
    installed = _vce_tesseract_installed_languages()
    languages = [
        _VCE_RECOGNITION_LANGUAGE_CATALOG[code]["tesseract"]
        for code in selected
        if _VCE_RECOGNITION_LANGUAGE_CATALOG[code]["tesseract"] in installed
    ]
    if not languages:
        return "unavailable", "", (
            "Среди выбранных языков нет установленных Tesseract traineddata. "
            "Установите соответствующие языковые данные; подмена на rus/eng запрещена."
        )
    return "tesseract-cli", "+".join(languages), (
        "FFmpeg + Tesseract CLI доступны; используются только выбранные установленные языки: "
        + "+".join(languages)
    )


def _vce_ffmpeg_ocr_capability(recognition_languages=None) -> tuple[bool, str]:
    backend, _language, message = _vce_detect_ffmpeg_ocr_backend(recognition_languages)
    return backend != "unavailable", message
'''


def _replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ValueError(f"{label}: ожидался один якорь, найдено {count}")
    return text.replace(old, new, 1)


def patch_engine(text: str) -> str:
    if MARKER in text:
        return text
    # Add the shared language registry and the strict allow-list-aware helpers.
    anchor = "def apple_vision_ocr(image: Image.Image) -> str:\n"
    text = _replace_once(text, anchor, HELPERS + "\n", "Apple OCR function anchor")
    text = _replace_once(text, OLD_APPLE_BODY, NEW_APPLE_BODY, "Apple Vision language fallback")

    # Tesseract capability is based on the installed traineddata and selected codes only.
    pattern = re.compile(
        r"def _vce_detect_ffmpeg_ocr_backend\(\) -> tuple\[str, str, str\]:.*?"
        r"def _vce_parse_ffmpeg_ocr_metadata\(raw: str\) -> list\[dict\]:",
        re.S,
    )
    replacement = NEW_TESSERACT_FUNCTIONS + "\n\ndef _vce_parse_ffmpeg_ocr_metadata(raw: str) -> list[dict]:"
    text, count = pattern.subn(replacement, text, count=1)
    if count != 1:
        raise ValueError("Не найден ожидаемый блок Tesseract backend")

    text = _replace_once(
        text,
        "def _vce_run_ffmpeg_ocr(video_path: str, interval_seconds: int, workers: int = 2) -> tuple[list[dict], str]:\n",
        "def _vce_run_ffmpeg_ocr(video_path: str, interval_seconds: int, workers: int = 2, recognition_languages=None) -> tuple[list[dict], str]:\n",
        "Tesseract runner signature",
    )
    text = _replace_once(
        text,
        "    backend, language, status = _vce_detect_ffmpeg_ocr_backend()\n",
        "    backend, language, status = _vce_detect_ffmpeg_ocr_backend(recognition_languages)\n",
        "Tesseract backend call",
    )
    # Native FFmpeg OCR has no dependable traineddata inventory; fail closed instead of bypassing the CLI check.
    native_start = "    if backend == \"ffmpeg-filter\":\n"
    native_end = "    ffmpeg = _vce_which_binary(\"ffmpeg\")\n    tesseract = _vce_which_binary(\"tesseract\")\n"
    if text.count(native_start) != 1:
        raise ValueError("Не найдена граница native FFmpeg OCR fallback")
    native_index = text.find(native_start)
    end_index = text.find(native_end, native_index + len(native_start))
    if end_index < 0:
        raise ValueError("Не найдена конечная граница native FFmpeg OCR fallback")
    before = text[:native_index]
    after = text[end_index + len(native_end):]
    text = before + native_end + after

    text = _replace_once(
        text,
        "def _vce_run_ffmpeg_ocr_timed(video_path: str, interval_seconds: int, workers: int = 2) -> tuple[list[dict], str, float]:\n",
        "def _vce_run_ffmpeg_ocr_timed(video_path: str, interval_seconds: int, workers: int = 2, recognition_languages=None) -> tuple[list[dict], str, float]:\n",
        "Tesseract timed runner signature",
    )
    text = _replace_once(
        text,
        "        records, message = _vce_run_ffmpeg_ocr(video_path, interval_seconds, workers)\n",
        "        records, message = _vce_run_ffmpeg_ocr(video_path, interval_seconds, workers, recognition_languages)\n",
        "Tesseract timed runner call",
    )

    # Cache key includes locale choices so a previous OCR result cannot cross language policies.
    text = _replace_once(
        text,
        "def _vce_cached_apple_vision_ocr(image):\n",
        "def _vce_cached_apple_vision_ocr(image, recognition_languages=None):\n",
        "Apple OCR cache signature",
    )
    text = _replace_once(
        text,
        "    key = digest.hexdigest()\n    if key in _VCE_OCR_CACHE:\n",
        "    selected = _vce_normalize_recognition_languages(setting(\"recognition_languages\", _VCE_DEFAULT_RECOGNITION_LANGUAGES) if recognition_languages is None else recognition_languages)\n    digest.update(\"|\".join(selected).encode(\"utf-8\"))\n    key = digest.hexdigest()\n    if key in _VCE_OCR_CACHE:\n",
        "Apple OCR cache key",
    )
    text = _replace_once(text, "    result = apple_vision_ocr(image)\n", "    result = apple_vision_ocr(image, selected)\n", "Apple OCR cache invocation")

    # Expose language selection in settings GET/POST and migrate the former Apple-only setting.
    text = _replace_once(
        text,
        '        "analysis_mode": "full", "enable_ffmpeg_ocr": False, "ffmpeg_ocr_interval": 5,\n',
        '        "analysis_mode": "full", "recognition_languages": _vce_legacy_apple_languages(persisted.get("apple_ocr_languages", ["ru-RU", "en-US"])), "enable_ffmpeg_ocr": False, "ffmpeg_ocr_interval": 5,\n',
        "UI settings defaults",
    )
    text = _replace_once(
        text,
        '        ffmpeg_ocr_available, ffmpeg_ocr_reason = _vce_ffmpeg_ocr_capability()\n',
        '        ffmpeg_ocr_available, ffmpeg_ocr_reason = _vce_ffmpeg_ocr_capability(recognition_languages)\n',
        "Analyze OCR capability language argument",
    )
    text = _replace_once(
        text,
        '    result["ffmpeg_ocr_available"], result["ffmpeg_ocr_reason"] = _vce_ffmpeg_ocr_capability()\n',
        '    result["ffmpeg_ocr_available"], result["ffmpeg_ocr_reason"] = _vce_ffmpeg_ocr_capability(result["recognition_languages"])\n'
        '    result["recognition_language_options"] = _vce_recognition_language_status()\n',
        "UI settings language availability",
    )
    text = _replace_once(
        text,
        '    for key, value in payload.items():\n        if key == "analysis_mode":\n',
        '    for key, value in payload.items():\n'
        '        if key == "recognition_languages":\n'
        '            try:\n'
        '                value = _vce_normalize_recognition_languages(value)\n'
        '            except ValueError as exc:\n'
        '                raise HTTPException(422, str(exc)) from exc\n'
        '        elif key == "analysis_mode":\n',
        "UI settings POST validation",
    )

    # Request-scoped languages are sent with every analysis rather than relying only on saved globals.
    text = _replace_once(
        text,
        '    word_timestamps: bool = Form(\n        bool(setting("word_timestamps", True)),\n        description="Временные метки отдельных слов Whisper для привязки речи к сценам",\n    ),\n',
        '    word_timestamps: bool = Form(\n        bool(setting("word_timestamps", True)),\n        description="Временные метки отдельных слов Whisper для привязки речи к сценам",\n    ),\n'
        '    recognition_languages_json: str = Form("", description="JSON-массив разрешённых языков распознавания"),\n',
        "Analyze request language field",
    )
    text = _replace_once(
        text,
        '    analysis_mode = (analysis_mode or "full").strip().lower()\n',
        '    try:\n'
        '        recognition_languages = _vce_normalize_recognition_languages(\n'
        '            recognition_languages_json if recognition_languages_json.strip() else setting("recognition_languages", _VCE_DEFAULT_RECOGNITION_LANGUAGES)\n'
        '        )\n'
        '    except ValueError as exc:\n'
        '        raise HTTPException(422, str(exc)) from exc\n'
        '    analysis_mode = (analysis_mode or "full").strip().lower()\n',
        "Analyze request language validation",
    )

    # ASR: detect independently in 30s chunks, then discard every chunk outside the allow-list.
    old_asr = '''                        audio_res = await asyncio.to_thread(
                            w_model.transcribe,
                            temp_path,
                            word_timestamps=word_timestamps,
                            condition_on_previous_text=False,
                            temperature=0.0,
                            compression_ratio_threshold=1.8,
                        )
'''
    new_asr = '''                        audio_res, _vce_asr_language_note = await asyncio.to_thread(
                            _vce_transcribe_allowed_language_chunks,
                            w_model,
                            temp_path,
                            video_duration,
                            recognition_languages,
                            word_timestamps,
                        )
                        if _vce_asr_language_note:
                            print("[VCE ASR languages] " + _vce_asr_language_note)
'''
    text = _replace_once(text, old_asr, new_asr, "ASR transcription call")

    # Pass the same selection to optional Tesseract and Apple Vision workers.
    text = _replace_once(
        text,
        '_vce_run_ffmpeg_ocr_timed, temp_path, ffmpeg_ocr_interval, ffmpeg_ocr_workers\n',
        '_vce_run_ffmpeg_ocr_timed, temp_path, ffmpeg_ocr_interval, ffmpeg_ocr_workers, recognition_languages\n',
        "FFmpeg OCR task language argument",
    )
    text = _replace_once(
        text,
        '((_vce_cached_apple_vision_ocr if enable_ocr_cache else apple_vision_ocr), kf.get("original_image", kf["image"]))\n',
        '((_vce_cached_apple_vision_ocr if enable_ocr_cache else apple_vision_ocr), kf.get("original_image", kf["image"]), recognition_languages)\n',
        "Apple OCR call language argument",
    )

    # VLM scene and global summary get the exact same language whitelist.
    text = _replace_once(
        text,
        '                            full_visual_prompt = BASE_VISUAL_PROMPT\n',
        '                            full_visual_prompt = BASE_VISUAL_PROMPT\n',
        "VLM scene prompt anchor",
    )
    text = _replace_once(
        text,
        '                                    + visual_user_prompt.strip()\n'
        '                                )\n',
        '                                    + visual_user_prompt.strip()\n'
        '                                )\n'
        '                            full_visual_prompt += _vce_language_policy_prompt(recognition_languages)\n',
        "VLM scene policy after custom prompt",
    )
    text = _replace_once(
        text,
        '                            + summary_user_prompt.strip()\n'
        '                        )\n',
        '                            + summary_user_prompt.strip()\n'
        '                        )\n'
        '                    full_summary_prompt += _vce_language_policy_prompt(recognition_languages)\n',
        "VLM summary policy after custom prompt",
    )

    # Text LLM is no longer hard-coded to Russian; first checked language is output language.
    text = _replace_once(
        text,
        '    progress_callback: Optional[Any] = None,\n) -> Dict[str, Any]:\n',
        '    progress_callback: Optional[Any] = None,\n    recognition_languages=None,\n) -> Dict[str, Any]:\n',
        "Text LLM signature",
    )
    text = _replace_once(
        text,
        '            "Все формулировки пиши на русском языке; сохраняй точное написание брендов, имён, стандартов, файлов, команд и технических терминов. "\n',
        '            "Все аналитические формулировки пиши на языке " + _VCE_RECOGNITION_LANGUAGE_CATALOG[_vce_normalize_recognition_languages(setting("recognition_languages", _VCE_DEFAULT_RECOGNITION_LANGUAGES) if recognition_languages is None else recognition_languages)[0]]["name"] + "; разрешённые языки входных источников: " + ", ".join(_VCE_RECOGNITION_LANGUAGE_CATALOG[code]["name"] for code in _vce_normalize_recognition_languages(setting("recognition_languages", _VCE_DEFAULT_RECOGNITION_LANGUAGES) if recognition_languages is None else recognition_languages)) + ". "\n'
        '            "Не распознавай и не реконструируй сведения на языках вне этого списка; не угадывай нечитаемые фрагменты. "\n'
        '            "Сохраняй точное написание брендов, имён, стандартов, файлов, команд и технических терминов. "\n',
        "Text LLM language policy",
    )
    text = _replace_once(
        text,
        '             + "\\\\n\\\\n"\n'
        '             + coverage_note\n',
        '             + _vce_language_policy_prompt(recognition_languages)\n'
        '             + "\\\\n\\\\n"\n'
        '             + coverage_note\n',
        "Text LLM final language policy",
    )
    text = _replace_once(
        text,
        '                        _ui_text_llm_progress_callback,\n                    )\n',
        '                        _ui_text_llm_progress_callback,\n'
        '                        recognition_languages,\n'
        '                    )\n',
        "Text LLM call language argument",
    )
    # Diagnostics record the allow-list actually used in this request.
    text = _replace_once(
        text,
        '            "backend": _vce_detect_ffmpeg_ocr_backend()[0],\n',
        '            "backend": _vce_detect_ffmpeg_ocr_backend(recognition_languages)[0],\n',
        "Tesseract diagnostics language argument",
    )
    text = _replace_once(
        text,
        '            "ffmpeg_ocr": {\n',
        '            "recognition_languages": recognition_languages,\n'
        '            "recognition_language_policy": "whitelist; ASR detected per 30-second chunk; non-selected chunks discarded",\n'
        '            "ffmpeg_ocr": {\n',
        "Recognition languages response metadata",
    )

    ast.parse(text)
    return text


LANGUAGE_CHECKBOXES = '''<!-- VCE_RECOGNITION_LANGUAGES_V1 -->
<div class="setting-checks" id="cfg-recognition-languages" style="grid-column:1 / -1">
  <strong style="grid-column:1 / -1">Языки распознавания (можно выбрать несколько)</strong>
  <label><input type="checkbox" value="ru" data-recognition-language="ru" checked> Русский <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="en" data-recognition-language="en" checked> English <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="pt" data-recognition-language="pt"> Português <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="es" data-recognition-language="es"> Español <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="fr" data-recognition-language="fr"> Français <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="de" data-recognition-language="de"> Deutsch <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="it" data-recognition-language="it"> Italiano <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="nl" data-recognition-language="nl"> Nederlands <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="pl" data-recognition-language="pl"> Polski <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="tr" data-recognition-language="tr"> Türkçe <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="uk" data-recognition-language="uk"> Українська <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="zh" data-recognition-language="zh"> 中文（简体） <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="ja" data-recognition-language="ja"> 日本語 <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="ko" data-recognition-language="ko"> 한국어 <small class="recognition-meta"></small></label>
  <label><input type="checkbox" value="ar" data-recognition-language="ar"> العربية <small class="recognition-meta"></small></label>
  <span class="hint" id="recognition-languages-hint" style="grid-column:1 / -1">Первый отмеченный сверху язык — язык описаний и итогового конспекта. Все отмеченные языки разрешены для речи и текста на экране. Для OCR учитываются только реально установленные языковые данные.</span>
</div>
'''

RECOGNITION_UI_JS = '''
  function fillRecognitionLanguageChecks(s) {
    const legacy = Array.isArray(s.apple_ocr_languages) ? s.apple_ocr_languages : [];
    const legacyMap = {"ru-RU":"ru", "en-US":"en", "pt-BR":"pt", "es-ES":"es", "fr-FR":"fr", "de-DE":"de", "it-IT":"it", "nl-NL":"nl", "pl-PL":"pl", "tr-TR":"tr", "uk-UA":"uk", "zh-Hans":"zh", "ja-JP":"ja", "ko-KR":"ko", "ar-SA":"ar"};
    const selected = Array.isArray(s.recognition_languages) ? s.recognition_languages : legacy.map(x => legacyMap[x]).filter(Boolean);
    document.querySelectorAll('#cfg-recognition-languages input[data-recognition-language]').forEach(el => {
      el.checked = selected.includes(el.value);
    });
    const statuses = new Map((s.recognition_language_options || []).map(item => [item.code, item]));
    document.querySelectorAll('#cfg-recognition-languages input[data-recognition-language]').forEach(el => {
      const item = statuses.get(el.value);
      const meta = el.parentElement.querySelector('.recognition-meta');
      if (!meta || !item) return;
      const available = [];
      if (item.whisper) available.push('ASR');
      if (item.vision) available.push('Vision');
      if (item.tesseract) available.push('Tesseract');
      meta.textContent = available.length ? '· ' + available.join(' / ') : '· нет локального распознавателя';
      meta.title = 'Доступность установленных backend: ' + (available.join(', ') || 'нет');
    });
  }
'''


def patch_ui(text: str) -> str:
    if UI_MARKER in text:
        return text
    text = _replace_once(
        text,
        '<label><input id="cfg-apple-ocr" type="checkbox" checked> Apple Vision OCR</label>\n',
        '<label><input id="cfg-apple-ocr" type="checkbox" checked> Apple Vision OCR</label>\n' + LANGUAGE_CHECKBOXES,
        "Recognition checkbox insertion",
    )
    text = _replace_once(
        text,
        "    text_llm_max_tokens: Number(document.getElementById('cfg-text-llm-max-tokens').value)\n",
        "    text_llm_max_tokens: Number(document.getElementById('cfg-text-llm-max-tokens').value),\n"
        "    recognition_languages: [...document.querySelectorAll('#cfg-recognition-languages input[data-recognition-language]:checked')].map(el => el.value)\n",
        "Recognition settings read",
    )
    text = _replace_once(
        text,
        "    for (const [id,key] of Object.entries(checks)) if (s[key] !== undefined) document.getElementById(id).checked = Boolean(s[key]);\n",
        "    for (const [id,key] of Object.entries(checks)) if (s[key] !== undefined) document.getElementById(id).checked = Boolean(s[key]);\n"
        "    fillRecognitionLanguageChecks(s);\n",
        "Recognition settings fill",
    )
    text = _replace_once(
        text,
        "  async function loadSettings() {\n",
        RECOGNITION_UI_JS + "\n   async function loadSettings() {\n",
        "Recognition availability JS helper",
    )
    text = _replace_once(
        text,
        "      const res = await fetch('/api/v1/ui-settings', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(readSettings())});\n",
        "      const config = readSettings();\n"
        "      if (!config.recognition_languages.length) throw new Error('Выберите хотя бы один язык распознавания.');\n"
        "      const res = await fetch('/api/v1/ui-settings', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(config)});\n",
        "Recognition settings save request",
    )
    text = _replace_once(
        text,
        "      for (const [key, value] of Object.entries(cfg)) form.append(key, String(value));\n",
        "      for (const [key, value] of Object.entries(cfg)) form.append(key, String(value));\n"
        "      form.append('recognition_languages_json', JSON.stringify(cfg.recognition_languages));\n",
        "Recognition analysis form field",
    )
    return text


def patch_config(text: str) -> str:
    try:
        data = json.loads(text)
    except Exception as exc:
        raise ValueError(f"Некорректный JSON в {CONFIG}: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"{CONFIG} должен содержать JSON-объект")
    if "recognition_languages" not in data:
        legacy = data.get("apple_ocr_languages", ["ru-RU", "en-US"])
        locale_map = {"ru-RU":"ru", "en-US":"en", "pt-BR":"pt", "es-ES":"es", "fr-FR":"fr", "de-DE":"de", "it-IT":"it", "nl-NL":"nl", "pl-PL":"pl", "tr-TR":"tr", "uk-UA":"uk", "zh-Hans":"zh", "ja-JP":"ja", "ko-KR":"ko", "ar-SA":"ar"}
        data["recognition_languages"] = list(dict.fromkeys(locale_map[x] for x in legacy if x in locale_map)) or ["ru", "en"]
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def build_changes(project: Path) -> Dict[Path, Tuple[str, str]]:
    engine_path = project / ENGINE
    ui_path = project / UI
    if not engine_path.is_file() or not ui_path.is_file():
        raise FileNotFoundError(
            f"Не найдены {ENGINE} и/или {UI} в {project}. Ожидается корень VideoContext Engine v3.19."
        )
    engine_old = engine_path.read_text(encoding="utf-8")
    ui_old = ui_path.read_text(encoding="utf-8")
    changes = {
        ENGINE: (engine_old, patch_engine(engine_old)),
        UI: (ui_old, patch_ui(ui_old)),
    }
    config_candidates = [
        CONFIG,
        Path("config/videocontext_settings.apple_silicon.example.json"),
        Path("config/videocontext_settings.local-example.json"),
    ]
    for relative in config_candidates:
        config_path = project / relative
        if config_path.is_file():
            config_old = config_path.read_text(encoding="utf-8")
            changes[relative] = (config_old, patch_config(config_old))
    return changes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, default=Path.cwd(), help="Путь к корню VCE")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--dry-run", action="store_true", help="Показать diff, ничего не записывать")
    action.add_argument("--apply", action="store_true", help="Применить патч с резервными копиями")
    args = parser.parse_args()
    project = args.project.expanduser().resolve()
    try:
        changes = build_changes(project)
    except Exception as exc:
        print("ОШИБКА: " + str(exc), file=sys.stderr)
        return 2
    changed = [(path, old, new) for path, (old, new) in changes.items() if old != new]
    if not changed:
        print("Патч уже установлен. Изменений нет.")
        return 0
    if args.dry_run:
        print(f"DRY RUN: будет изменено файлов: {len(changed)}; запись не выполняется.")
        for path, old, new in changed:
            print(f"\n--- {path} ---")
            diff = difflib.unified_diff(old.splitlines(), new.splitlines(), fromfile=str(path), tofile=str(path) + " [patched]", lineterm="")
            for line in list(diff)[:180]:
                print(line)
        print("\nDRY RUN завершён. Файлы не изменены.")
        return 0
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backups = []
    try:
        for relative, old, new in changed:
            target = project / relative
            backup = target.with_name(target.name + f".before_recognition_languages_{stamp}.bak")
            shutil.copy2(target, backup)
            backups.append(backup)
            temp = target.with_name(target.name + ".recognition_languages.tmp")
            temp.write_text(new, encoding="utf-8")
            temp.replace(target)
    except Exception as exc:
        print("ОШИБКА установки: " + str(exc), file=sys.stderr)
        print("Резервные копии: " + ", ".join(str(x) for x in backups), file=sys.stderr)
        return 3
    print("Патч установлен.")
    print("Изменены файлы: " + ", ".join(str(x[0]) for x in changed))
    print("Резервные копии:")
    for backup in backups:
        print("  " + str(backup))
    print("Перезапустите VCE. В настройках появится блок языков распознавания.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
